/* compile with "gcc -O" or "gcc -O2" */

void beep_stop(void);
void beep_start(unsigned int freq);

/* convert a number to frequency */
/* 0 is A, 1 is A#, 2 is B */
unsigned int key2freq(int key);
