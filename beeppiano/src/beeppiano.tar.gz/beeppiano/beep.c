#include <sys/io.h>
#include <asm/io.h>

static unsigned int playing_freq = 0;

void beep_stop(void){
  if(ioperm(0x61, 32, 1) < 0)
    return;
  outb(inb_p(0x61)&0xFC, 0x61);
  ioperm(0x61, 32, 0);
  
  playing_freq = 0;
  return;
}

void beep_start(unsigned int freq){
  unsigned int f = 0;

  if(freq == playing_freq)
    return;

  if(freq > 20 && freq < 32767)
    f = 1193180 / freq;
	
  if(f){

    if(ioperm(0x42, 2, 1) < 0)
      return;
    if(ioperm(0x61, 32, 1) < 0)
      return;

    outb_p(inb_p(0x61)|3, 0x61);
    outb_p(0xB6, 0x43);
    outb_p(f & 0xff, 0x42);
    outb((f >> 8) & 0xff, 0x42);

    ioperm(0x42, 2, 0);
    ioperm(0x61, 32, 0);

    playing_freq = freq;
  }else
    beep_stop();

  return;
}

#include <math.h>
unsigned int key2freq(int key){
  return 440 * pow(2, key / 12.0);
}
