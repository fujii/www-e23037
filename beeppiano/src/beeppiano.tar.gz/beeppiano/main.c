#include <stdio.h>
#include "beep.h"

int table[128];

void kb106(void){
  int i;

  for(i=0;i<=127;i++){
    switch(i){
    case 30: table[i] = key2freq(-9);break;
    case 17: table[i] = key2freq(-8);break;
    case 31: table[i] = key2freq(-7);break;
    case 18: table[i] = key2freq(-6);break;
    case 32: table[i] = key2freq(-5);break;
    case 33: table[i] = key2freq(-4);break;
    case 20: table[i] = key2freq(-3);break;
    case 34: table[i] = key2freq(-2);break;
    case 21: table[i] = key2freq(-1);break;
    case 35: table[i] = key2freq(0);break;
    case 22: table[i] = key2freq(1);break;
    case 36: table[i] = key2freq(2);break;
    case 37: table[i] = key2freq(3);break;
    case 24: table[i] = key2freq(4);break;
    case 38: table[i] = key2freq(5);break;
    case 25: table[i] = key2freq(6);break;
    case 39: table[i] = key2freq(7);break;
    case 40: table[i] = key2freq(8);break;
    case 27: table[i] = key2freq(9);break;
    case 43: table[i] = key2freq(10);break;
    default: table[i] = 0;break;
    }
  }
}

int main(void){
  FILE * fp;
  int c;
  int key = 0;

  kb106();

  fputs("beeppiano for linux\n"
	"[ESC]:exit\n", stdout);

  fp = fopen("/dev/console", "r");

  while(c = fgetc(fp)){
    if(c == 129 || c == -1)
      break;

    if(c < 129){
      key = c; 
      beep_start(table[c]);
    }else if( c == key + 128)
      beep_stop();
  }

  beep_stop();
  fclose(fp);

  return 0;
}
